Kelompok 7

Anggota
- Leonardo Jonathan Fernandez Namlay (00000058084)
- Jonathan Setyohadi (00000059549)
- Adhy Ardana Setyawan (00000059569)
- Andrew Thomas Agustinus (00000059999)

Link Youtube Video Presentasi:
https://youtu.be/hPkh6P14w7s 

Aturan
How to play:
-Player memilih avatar yang tersedia
-Player memilih nama 
-Player memilih jurusan
-Tekan Play dan permainan akan langsung dimulai
-Jaga kestabilan tingkatan happines, hunger, health, dan knowledge karakter
-Terus melakukan aktivitas hingga 7 hari
-Setelah 7 hari maka akan di evaluasi berdasarkan status bar

Peraturan main :
-status akan turun tiap menit di dalam game.
-Aksi makan akan memenuhi hunger bar dan mengurangi happiness bar.
-Aksi main menambah happiness bar dan mengurangi health bar.
-Aksi tidur akan menambah  health bar dan mengurangi hunger bar.
-Aksi belajar akan mengurangi semua stat lain dan menaikkan stat belajar.
-Aksi Sosial akan menambah  sosial bar.
-Jika salah satu stat kurang dari 20 akan diberi warning tiap 10 menit in-game.
-Kondisi menang setelah 7 hari dalam game berlalu.

Fitur permainan :
-Pilih avatar
-Random button untuk nama.
-Avatar melakukan aksi yang dipilih.
-1 menit di game sama dengan 3 detik di dunia nyata.