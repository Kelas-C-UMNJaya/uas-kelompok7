import React from "react";

class Victory extends React.Component {
  render() {
    return (
      <div id="Victory" className="d-none">
        <h1>Congratulations!!!</h1>
      </div>
    );
  }
}

export default Victory;
