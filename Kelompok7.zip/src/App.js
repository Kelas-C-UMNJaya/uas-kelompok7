import React from 'react';
import './App.css';
import Bungkus from './components/bungkus';


function App() {
  return (
    <Bungkus/>
  );
}

export default App;
